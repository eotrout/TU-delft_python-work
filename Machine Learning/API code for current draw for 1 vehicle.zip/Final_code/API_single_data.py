import requests
import json

site_id = "caltech"
api_url = "https://ev.caltech.edu/api/v1/sessions/caltech/ts/?" \
          "where=connectionTime>=\"Wed, 5 May 2018 00:00:00 GMT\"" \
          "and connectionTime<=\"Thu, 6 May 2018 00:00:00 GMT\"" \
          "&pretty"
# api_url = "https://ev.caltech.edu/api/v1/sessions/caltech/?where=connectionTime>=\"Wed, 02 May 2018 00:00:00 GMT\"and connectionTime<=\"Thu, 03 May 2018 00:00:00 GMT\"&pretty"
# api_url = "https://ev.caltech.edu/api/v1/sessions/caltech"

api_key = "36LxzbXyUgmL6hi6UYJD4gLwHyUps1wbdhkDLpCsL60"

headers = {
    "Authorization": f"Token {api_key}"
}

params = {
    "page": 1,
    "limit": 100,  # set the maximum number of results per page to 100
}

all_data = []  # list to store all the retrieved data

while True:
    response = requests.get(api_url, headers=headers, params=params)
    print(response)
    if response.status_code == 200:
        data = response.json()
        all_data.extend(data["_items"])  # add the items from the current page to the list

        # check if there are more pages to retrieve
        if len(all_data) < data["_meta"]["total"]:
            params["page"] += 1  # move to the next page
        else:
            break  # no more pages, exit the loop
    else:
        print("Error:", response.status_code)
        break  # exit the loop if there's an error

# write all the retrieved data to a JSON file
with open("all_data.json", "w") as f:
    json.dump(all_data, f)

print("Data written to file.")
