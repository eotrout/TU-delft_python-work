# This code write json files with EV charging data from the server, it creates a new file for every day.

import requests
import json
from datetime import datetime, timedelta
import os

# configurations
site_id = "caltech"
start_date_str = "Wed, 13 Feb 2019 00:00:00 GMT"
end_date_str = "Tue, 14 Feb 2019 00:00:00 GMT"
timestamps = True


if timestamps == True:
    api_url_template = "https://ev.caltech.edu/api/v1/sessions/caltech/ts/?" \
                       "where=connectionTime>=\"{}\"" \
                       "and connectionTime<=\"{}\"" \
                       "&pretty"

else:
    api_url_template = "https://ev.caltech.edu/api/v1/sessions/caltech/?" \
                   "where=connectionTime>=\"{}\"" \
                   "and connectionTime<=\"{}\"" \
                   "&pretty"

api_key = "1uJlA5fCP_50zY3W6OOK8-TxQ2bkKBknni0uA1uOjq4"

headers = {
    "Authorization": f"Token {api_key}"
}


date_format = "%a, %d %b %Y %H:%M:%S %Z"


start_date = datetime.strptime(start_date_str, date_format)
end_date = datetime.strptime(end_date_str, date_format)

delta = timedelta(days=1)
count = 1
while start_date <= end_date:

    all_data = []  # list to store all the retrieved data
    date_str = start_date.strftime(date_format) + 'GMT'
    date_str_stop = (start_date + delta).strftime(date_format) + 'GMT'
    api_url = api_url_template.format(date_str, date_str_stop)
    # print(api_url)  # for debugging purposes


    while True:
        params = {
            "page": 1,
            "limit": 100,  # set the maximum number of results per page to 100
        }
        response = requests.get(api_url, headers=headers, params=params)
        # print(response)
        if response.status_code == 200:
            data = response.json()
            all_data.extend(data["_items"])  # add the items from the current page to the list

            # check if there are more pages to retrieve
            # print(len(all_data), data["_meta"]["total"])
            if len(all_data) < data["_meta"]["total"]:
                params["page"] += 1  # move to the next page
            else:
                break  # no more pages, exit the loop
        else:
            print("Error:", response.status_code)
            break  # exit the loop if there's an error

    # write all the retrieved data to a JSON file
    if timestamps == True:
        file_name = os.getcwd() + "\EV data per day\EV_TS_data" + start_date.strftime("%Y-%m-%d") + ".json"
    else:
        file_name = os.getcwd() + "\EV data per day without TS\EV_data" + start_date.strftime("%Y-%m-%d") + ".json"

    with open(file_name, "w") as f:
        json.dump(all_data, f)

    print(f"Data written to file {count}.")
    count += 1
    start_date += delta
