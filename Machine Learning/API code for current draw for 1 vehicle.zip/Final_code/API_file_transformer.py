import json
import os
from datetime import datetime, timedelta

# settings
pilotSignal = False
time_interval = 2       #In min

# load the JSON data from the file
day = "2019-02-11"
file_name = os.path.join(os.getcwd(), "EV data per day", "EV_TS_data" + day  + ".json")
with open(file_name, 'r') as f:
    data = json.load(f)

# iterate over the list of dictionaries and remove the "pilotSignal" key
if pilotSignal == False:
    for record in data:
        del record['pilotSignal']

for id in range(len(data)):
    try:
        timestamps = data[id]['chargingCurrent']["timestamps"]
        currents = data[id]['chargingCurrent']['current']

        previous_time = None
        index_list = []
        for i, timestamp in enumerate(timestamps):
            current_time = datetime.strptime(timestamp, '%a, %d %b %Y %H:%M:%S %Z')
            if previous_time is None or current_time - previous_time >= timedelta(minutes=time_interval):
                index_list.append(i)
                previous_time = current_time

        # Create a new list of timestamps that correspond to the index_list
        new_timestamps = [timestamps[i] for i in index_list]
        new_currents = [currents[i] for i in index_list]

        # update the data with the new list of timestamps and currents
        data[id]['chargingCurrent']["timestamps"] = new_timestamps
        data[id]['chargingCurrent']["current"] = new_currents
    except:
        id = data[id]['_id']
        print(f'Failure in obtaing chargingCurrent for _id: {id}')



# Create a new list to hold the unique dictionaries
unique_data = []

# Loop through the original list of dictionaries and check if each dictionary is already in the unique list
for dictionary in data:
    if dictionary not in unique_data:
        unique_data.append(dictionary)



# save the modified data back to the file
output_file_name = os.path.join(os.getcwd(), "EV data per day", "small_EV_TS_data" + day + ".json")
with open(output_file_name, 'w') as f:
    json.dump(unique_data, f)
print('Writen file')
