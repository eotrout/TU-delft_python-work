import json
import matplotlib.pyplot as plt
import os
from datetime import datetime, timedelta

day = "2019-02-11"
file_name = os.getcwd() + "\EV data per day\small_EV_TS_data" + day + ".json"
data = ""
with open(file_name, 'r') as file:
    data = json.load(file)

fig, ax = plt.subplots()
for car in range(len(data)):

    # Open the JSON file and read its contents


    # Print the contents of the JSON file
    timestamps = (data[car]['chargingCurrent']["timestamps"])
    current = (data[car]['chargingCurrent']["current"])

    # Plot the data
    fig, ax = plt.subplots()
    ax.plot(timestamps, current)
    ax.plot(data[car]["doneChargingTime"], 0,'ro')
    # Set the xtick frequency to every 5th timestamp
    xtick_int = int(len(timestamps) / 15)
    if xtick_int == 0:
        xtick_int = 1
    xtick_locs = timestamps[::xtick_int]
    xtick_labels = [datetime.strptime(timestamp, '%a, %d %b %Y %H:%M:%S %Z').strftime('%H:%M') for timestamp in
                    xtick_locs]
    ax.set_xticks(xtick_locs)
    ax.set_xticklabels(xtick_labels)
    title = 'Current plot, ' + str(data[car]['connectionTime']) + ', Car number: ' + str(car)
    ax.set_title(title)

    # Rotate the x-axis labels by 45 degrees for better visibility
    plt.xticks(rotation=45)
    plt.ylabel('Current')
    plt.xlabel('Time')
    plt.show()




